var hierarchy =
[
    [ "MonoBehaviour", null, [
      [ "EditorTkEx.SceneTk", "class_editor_tk_ex_1_1_scene_tk.html", null ]
    ] ]
];