var indexSectionsWithContent =
{
  0: "bcdes",
  1: "s",
  2: "e",
  3: "bds",
  4: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions"
};

