var indexSectionsWithContent =
{
  0: "a",
  1: "a",
  2: "a",
  3: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files"
};

