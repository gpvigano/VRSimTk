var namespaces =
[
    [ "AssetBundleWorkshop", "namespace_asset_bundle_workshop.html", null ]
];