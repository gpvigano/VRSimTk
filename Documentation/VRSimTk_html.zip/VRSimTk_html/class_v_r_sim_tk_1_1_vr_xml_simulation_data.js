var class_v_r_sim_tk_1_1_vr_xml_simulation_data =
[
    [ "autoStart", "class_v_r_sim_tk_1_1_vr_xml_simulation_data.html#af2f4553b1365de15c37a650c747dee4c", null ],
    [ "description", "class_v_r_sim_tk_1_1_vr_xml_simulation_data.html#a45bd85f1a74706a29874056b71927fde", null ],
    [ "details", "class_v_r_sim_tk_1_1_vr_xml_simulation_data.html#a6e26e52a98ddf380184cd5ed7b23ed97", null ],
    [ "historyList", "class_v_r_sim_tk_1_1_vr_xml_simulation_data.html#aff53a628c66b5a99ed0cbebdb20f3b25", null ],
    [ "historyName", "class_v_r_sim_tk_1_1_vr_xml_simulation_data.html#aa14032d4c4fb8c9b752a1145c551c433", null ],
    [ "historyUri", "class_v_r_sim_tk_1_1_vr_xml_simulation_data.html#a316d3a2d29b5bb36d00ef1fe5482066a", null ]
];