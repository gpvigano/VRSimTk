var class_v_r_sim_tk_1_1_hide_roof =
[
    [ "objectToHide", "class_v_r_sim_tk_1_1_hide_roof.html#a8424ab0524ed5a6f5db3cbc954d9952b", null ],
    [ "observerTransform", "class_v_r_sim_tk_1_1_hide_roof.html#a09d71f7a6c6161f527541438715e02cd", null ],
    [ "verticalOffset", "class_v_r_sim_tk_1_1_hide_roof.html#ab91313c3b402a6b1fd01d7ab4e2b9d16", null ]
];