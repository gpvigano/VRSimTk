var hierarchy =
[
    [ "VRSimTk.AnimationRecord", "class_v_r_sim_tk_1_1_animation_record.html", null ],
    [ "VRSimTk.CsConv", "class_v_r_sim_tk_1_1_cs_conv.html", null ],
    [ "VRSimTk.EntityState", "class_v_r_sim_tk_1_1_entity_state.html", null ],
    [ "VRSimTk.MatUtil", "class_v_r_sim_tk_1_1_mat_util.html", null ],
    [ "MonoBehaviour", null, [
      [ "VRSimTk.AnimationLogParser", "class_v_r_sim_tk_1_1_animation_log_parser.html", null ],
      [ "VRSimTk.CrossPlatformCameraController", "class_v_r_sim_tk_1_1_cross_platform_camera_controller.html", null ],
      [ "VRSimTk.DataSync", "class_v_r_sim_tk_1_1_data_sync.html", [
        [ "VRSimTk.XmlDataSync", "class_v_r_sim_tk_1_1_xml_data_sync.html", null ]
      ] ],
      [ "VRSimTk.DataSyncUI", "class_v_r_sim_tk_1_1_data_sync_u_i.html", null ],
      [ "VRSimTk.DataUtil", "class_v_r_sim_tk_1_1_data_util.html", null ],
      [ "VRSimTk.EditorLikeCameraController", "class_v_r_sim_tk_1_1_editor_like_camera_controller.html", null ],
      [ "VRSimTk.EntityData", "class_v_r_sim_tk_1_1_entity_data.html", null ],
      [ "VRSimTk.EntityHistory", "class_v_r_sim_tk_1_1_entity_history.html", null ],
      [ "VRSimTk.EntityRepresentation", "class_v_r_sim_tk_1_1_entity_representation.html", null ],
      [ "VRSimTk.HideRoof", "class_v_r_sim_tk_1_1_hide_roof.html", null ],
      [ "VRSimTk.Relationship", "class_v_r_sim_tk_1_1_relationship.html", [
        [ "VRSimTk.ManyToManyRelationship", "class_v_r_sim_tk_1_1_many_to_many_relationship.html", null ],
        [ "VRSimTk.OneToManyRelationship", "class_v_r_sim_tk_1_1_one_to_many_relationship.html", [
          [ "VRSimTk.CompositionRelationship", "class_v_r_sim_tk_1_1_composition_relationship.html", null ],
          [ "VRSimTk.InclusionRelationship", "class_v_r_sim_tk_1_1_inclusion_relationship.html", null ]
        ] ],
        [ "VRSimTk.OneToOneRelationship", "class_v_r_sim_tk_1_1_one_to_one_relationship.html", null ]
      ] ],
      [ "VRSimTk.RelationshipRenderer", "class_v_r_sim_tk_1_1_relationship_renderer.html", null ],
      [ "VRSimTk.SimController", "class_v_r_sim_tk_1_1_sim_controller.html", null ],
      [ "VRSimTk.SimControllerUI", "class_v_r_sim_tk_1_1_sim_controller_u_i.html", null ],
      [ "VRSimTk.SimExecutor", "class_v_r_sim_tk_1_1_sim_executor.html", null ]
    ] ],
    [ "VRSimTk.RelationshipConnection", "class_v_r_sim_tk_1_1_relationship_connection.html", null ],
    [ "VRSimTk.SimEvent", "class_v_r_sim_tk_1_1_sim_event.html", null ],
    [ "VRSimTk.SimHistory", "class_v_r_sim_tk_1_1_sim_history.html", null ],
    [ "VRSimTk.SimLogParser", "class_v_r_sim_tk_1_1_sim_log_parser.html", null ],
    [ "VRSimTk.SimLogRecord", "class_v_r_sim_tk_1_1_sim_log_record.html", null ],
    [ "VRSimTk.VrXmlEntityData", "class_v_r_sim_tk_1_1_vr_xml_entity_data.html", null ],
    [ "VRSimTk.VrXmlHistoryData", "class_v_r_sim_tk_1_1_vr_xml_history_data.html", null ],
    [ "VRSimTk.VrXmlLocalTransform", "class_v_r_sim_tk_1_1_vr_xml_local_transform.html", null ],
    [ "VRSimTk.VrXmlRelationship", "class_v_r_sim_tk_1_1_vr_xml_relationship.html", [
      [ "VRSimTk.VrXmlManyToManyRelationship", "class_v_r_sim_tk_1_1_vr_xml_many_to_many_relationship.html", null ],
      [ "VRSimTk.VrXmlOneToManyRelationship", "class_v_r_sim_tk_1_1_vr_xml_one_to_many_relationship.html", [
        [ "VRSimTk.VrXmlCompositionRelationship", "class_v_r_sim_tk_1_1_vr_xml_composition_relationship.html", null ],
        [ "VRSimTk.VrXmlInclusionRelationship", "class_v_r_sim_tk_1_1_vr_xml_inclusion_relationship.html", null ]
      ] ],
      [ "VRSimTk.VrXmlOneToOneRelationship", "class_v_r_sim_tk_1_1_vr_xml_one_to_one_relationship.html", null ]
    ] ],
    [ "VRSimTk.VrXmlRepresentation", "class_v_r_sim_tk_1_1_vr_xml_representation.html", null ],
    [ "VRSimTk.VrXmlRotationMatrix", "class_v_r_sim_tk_1_1_vr_xml_rotation_matrix.html", null ],
    [ "VRSimTk.VrXmlSceneData", "class_v_r_sim_tk_1_1_vr_xml_scene_data.html", null ],
    [ "VRSimTk.VrXmlSimulationData", "class_v_r_sim_tk_1_1_vr_xml_simulation_data.html", null ],
    [ "VRSimTk.VrXmlVector3", "class_v_r_sim_tk_1_1_vr_xml_vector3.html", null ]
];