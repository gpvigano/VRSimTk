var class_v_r_sim_tk_1_1_vr_xml_one_to_one_relationship =
[
    [ "objectEntityId", "class_v_r_sim_tk_1_1_vr_xml_one_to_one_relationship.html#ab41a249135d2981ae56d7e3c6bc4f55f", null ],
    [ "subjectEntityId", "class_v_r_sim_tk_1_1_vr_xml_one_to_one_relationship.html#af7a862adfbf3fece6cefa28b24160477", null ]
];