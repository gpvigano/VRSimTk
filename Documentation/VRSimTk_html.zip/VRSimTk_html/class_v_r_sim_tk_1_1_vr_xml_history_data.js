var class_v_r_sim_tk_1_1_vr_xml_history_data =
[
    [ "entityId", "class_v_r_sim_tk_1_1_vr_xml_history_data.html#a840348f905e1896c103778a87cc9e494", null ],
    [ "fileName", "class_v_r_sim_tk_1_1_vr_xml_history_data.html#a015ec568195d98fe94b1dbdb0888c502", null ],
    [ "upAxisIsZ", "class_v_r_sim_tk_1_1_vr_xml_history_data.html#aaf055c966e496cfa9e93582cd28c9917", null ]
];