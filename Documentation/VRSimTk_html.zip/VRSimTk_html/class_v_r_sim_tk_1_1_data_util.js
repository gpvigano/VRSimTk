var class_v_r_sim_tk_1_1_data_util =
[
    [ "CreateNewEntityId", "class_v_r_sim_tk_1_1_data_util.html#ac6f4c297b745a32321ca980e914e3629", null ],
    [ "CreateNewId", "class_v_r_sim_tk_1_1_data_util.html#a1d86c559240fb915d59b40add119311e", null ],
    [ "DataSyncAvailable", "class_v_r_sim_tk_1_1_data_util.html#a1952d756f9be7471a08cf881ad2cfee8", null ],
    [ "FindEntity", "class_v_r_sim_tk_1_1_data_util.html#abd58338e0ad1fbfbbe416690799a3fad", null ],
    [ "GetEntities", "class_v_r_sim_tk_1_1_data_util.html#aec1ba3eb9061226e92973161baefcf2b", null ],
    [ "ReadFromXml< T >", "class_v_r_sim_tk_1_1_data_util.html#a57bab8515a87222fed3204e191258584", null ],
    [ "WriteToXml", "class_v_r_sim_tk_1_1_data_util.html#a305c2de97ffea1d4bab20960c5e66622", null ]
];