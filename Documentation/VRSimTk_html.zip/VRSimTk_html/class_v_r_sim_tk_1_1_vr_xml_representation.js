var class_v_r_sim_tk_1_1_vr_xml_representation =
[
    [ "AssetType", "class_v_r_sim_tk_1_1_vr_xml_representation.html#ac53e75c4b0ff1c06c1d1b650d3392028", [
      [ "None", "class_v_r_sim_tk_1_1_vr_xml_representation.html#ac53e75c4b0ff1c06c1d1b650d3392028a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Prefab", "class_v_r_sim_tk_1_1_vr_xml_representation.html#ac53e75c4b0ff1c06c1d1b650d3392028afc149351d98dcbf17361c6a449e6355e", null ],
      [ "AssetBundle", "class_v_r_sim_tk_1_1_vr_xml_representation.html#ac53e75c4b0ff1c06c1d1b650d3392028ae8cbe8f681e78018c49cfb82158030d8", null ],
      [ "Sphere", "class_v_r_sim_tk_1_1_vr_xml_representation.html#ac53e75c4b0ff1c06c1d1b650d3392028ab7095f057db3fefa7325ad93a04e14fd", null ],
      [ "Cube", "class_v_r_sim_tk_1_1_vr_xml_representation.html#ac53e75c4b0ff1c06c1d1b650d3392028aa296104f0c61a9cf39f4824d05315e12", null ],
      [ "Cylinder", "class_v_r_sim_tk_1_1_vr_xml_representation.html#ac53e75c4b0ff1c06c1d1b650d3392028a2ec2c2961c7ce5a114d969c1f562a563", null ],
      [ "Capsule", "class_v_r_sim_tk_1_1_vr_xml_representation.html#ac53e75c4b0ff1c06c1d1b650d3392028a4880c0f12c06dd6d142e7a40b041bf1a", null ],
      [ "Quad", "class_v_r_sim_tk_1_1_vr_xml_representation.html#ac53e75c4b0ff1c06c1d1b650d3392028ae9017664588010860a92ceb5f8fcb824", null ],
      [ "Plane", "class_v_r_sim_tk_1_1_vr_xml_representation.html#ac53e75c4b0ff1c06c1d1b650d3392028a0d3adee051531c15b3509b4d4d75ce7b", null ],
      [ "Model", "class_v_r_sim_tk_1_1_vr_xml_representation.html#ac53e75c4b0ff1c06c1d1b650d3392028aa559b87068921eec05086ce5485e9784", null ]
    ] ],
    [ "assetBundleName", "class_v_r_sim_tk_1_1_vr_xml_representation.html#ac413c5215484616cead96515048f4e6f", null ],
    [ "assetName", "class_v_r_sim_tk_1_1_vr_xml_representation.html#a22c73f3a5de6fe35ea97b64b509bdf2c", null ],
    [ "assetType", "class_v_r_sim_tk_1_1_vr_xml_representation.html#a33b9361917b12ae6f2e8220ea8438459", null ],
    [ "id", "class_v_r_sim_tk_1_1_vr_xml_representation.html#aa0a67830c3d71f0abe7e9fc7274897fb", null ],
    [ "importOptions", "class_v_r_sim_tk_1_1_vr_xml_representation.html#ae427d59c0edbd96a7969320225fe7bfb", null ],
    [ "isVisible", "class_v_r_sim_tk_1_1_vr_xml_representation.html#a7e0d813a69b871daf177568a1bcf6bb7", null ],
    [ "localTransform", "class_v_r_sim_tk_1_1_vr_xml_representation.html#a7f20d29cad653b84a4d42f4f0fc017a5", null ]
];