var searchData=
[
  ['originalupaxisisz',['OriginalUpAxisIsZ',['../class_v_r_sim_tk_1_1_data_sync.html#a04efb4076304b3364c8d01fbf49aab6d',1,'VRSimTk.DataSync.OriginalUpAxisIsZ()'],['../class_v_r_sim_tk_1_1_xml_data_sync.html#a078a9a6f109c1bc71cdbf8f4d3d6f4de',1,'VRSimTk.XmlDataSync.OriginalUpAxisIsZ()']]]
];
