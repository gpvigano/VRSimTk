var searchData=
[
  ['category',['Category',['../class_v_r_sim_tk_1_1_sim_event.html#a34ebedb252351c8f09664d5796d7a10e',1,'VRSimTk::SimEvent']]],
  ['createdrepresentations',['createdRepresentations',['../class_v_r_sim_tk_1_1_data_sync.html#a0b16f7878198121793d02aa96fc50ece',1,'VRSimTk::DataSync']]]
];
