var searchData=
[
  ['activevariants',['ActiveVariants',['../class_v_r_sim_tk_1_1_data_sync.html#a046da53066ea8e2059b52f28e9edb702',1,'VRSimTk.DataSync.ActiveVariants()'],['../class_v_r_sim_tk_1_1_xml_data_sync.html#afa8117b809eabd4104ad58e73210044a',1,'VRSimTk.XmlDataSync.ActiveVariants()']]]
];
