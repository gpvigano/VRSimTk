var class_v_r_sim_tk_1_1_vr_xml_entity_data =
[
    [ "VrXmlEntityData", "class_v_r_sim_tk_1_1_vr_xml_entity_data.html#a8bbd8bfd40973a4408d9b36b6243a19a", null ],
    [ "description", "class_v_r_sim_tk_1_1_vr_xml_entity_data.html#adfa88e29f121c1329d5fd4a30fc09c6f", null ],
    [ "id", "class_v_r_sim_tk_1_1_vr_xml_entity_data.html#aef52afb1cb6e00ddb22d6823ccc94eca", null ],
    [ "localTransform", "class_v_r_sim_tk_1_1_vr_xml_entity_data.html#aec746f0c0c2c0bfa34b43b903617739c", null ],
    [ "name", "class_v_r_sim_tk_1_1_vr_xml_entity_data.html#a2070c06c9cd945183bf43be198bd5f3b", null ],
    [ "representation", "class_v_r_sim_tk_1_1_vr_xml_entity_data.html#a44160a6bd22ed1929ecd7db895940dfe", null ],
    [ "type", "class_v_r_sim_tk_1_1_vr_xml_entity_data.html#a5be5b84d5615643be820169bed628159", null ]
];