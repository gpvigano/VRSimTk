var class_v_r_sim_tk_1_1_entity_representation =
[
    [ "AssetPrimType", "class_v_r_sim_tk_1_1_entity_representation.html#a118d2cf5c29bb3c335e4a9656ae22e60", [
      [ "None", "class_v_r_sim_tk_1_1_entity_representation.html#a118d2cf5c29bb3c335e4a9656ae22e60a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Sphere", "class_v_r_sim_tk_1_1_entity_representation.html#a118d2cf5c29bb3c335e4a9656ae22e60ab7095f057db3fefa7325ad93a04e14fd", null ],
      [ "Cube", "class_v_r_sim_tk_1_1_entity_representation.html#a118d2cf5c29bb3c335e4a9656ae22e60aa296104f0c61a9cf39f4824d05315e12", null ],
      [ "Cylinder", "class_v_r_sim_tk_1_1_entity_representation.html#a118d2cf5c29bb3c335e4a9656ae22e60a2ec2c2961c7ce5a114d969c1f562a563", null ],
      [ "Capsule", "class_v_r_sim_tk_1_1_entity_representation.html#a118d2cf5c29bb3c335e4a9656ae22e60a4880c0f12c06dd6d142e7a40b041bf1a", null ],
      [ "Quad", "class_v_r_sim_tk_1_1_entity_representation.html#a118d2cf5c29bb3c335e4a9656ae22e60ae9017664588010860a92ceb5f8fcb824", null ],
      [ "Plane", "class_v_r_sim_tk_1_1_entity_representation.html#a118d2cf5c29bb3c335e4a9656ae22e60a0d3adee051531c15b3509b4d4d75ce7b", null ]
    ] ],
    [ "AssetType", "class_v_r_sim_tk_1_1_entity_representation.html#afb275deabe49c697ba5bd4972a9e5309", [
      [ "None", "class_v_r_sim_tk_1_1_entity_representation.html#afb275deabe49c697ba5bd4972a9e5309a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Prefab", "class_v_r_sim_tk_1_1_entity_representation.html#afb275deabe49c697ba5bd4972a9e5309afc149351d98dcbf17361c6a449e6355e", null ],
      [ "AssetBundle", "class_v_r_sim_tk_1_1_entity_representation.html#afb275deabe49c697ba5bd4972a9e5309ae8cbe8f681e78018c49cfb82158030d8", null ],
      [ "Primitive", "class_v_r_sim_tk_1_1_entity_representation.html#afb275deabe49c697ba5bd4972a9e5309a07ee3427562e4f1a5c9f2bfb17fd9eee", null ],
      [ "Model", "class_v_r_sim_tk_1_1_entity_representation.html#afb275deabe49c697ba5bd4972a9e5309aa559b87068921eec05086ce5485e9784", null ]
    ] ],
    [ "assetBundleName", "class_v_r_sim_tk_1_1_entity_representation.html#a08d1fa88b2848d978b50e71414e52691", null ],
    [ "assetName", "class_v_r_sim_tk_1_1_entity_representation.html#a02f521a9ac0023b4a8ff49ee3a159bb0", null ],
    [ "assetPrimType", "class_v_r_sim_tk_1_1_entity_representation.html#a425ba0caf2db2bc45ca2da98d9f59cf1", null ],
    [ "assetType", "class_v_r_sim_tk_1_1_entity_representation.html#a4b43436e8f2bb0fe582bfadc34be0600", null ],
    [ "importOptions", "class_v_r_sim_tk_1_1_entity_representation.html#a74b9a1383bb91b74773c235a8de35511", null ]
];